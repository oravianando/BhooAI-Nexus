// Shared sidebar nav for the BhooAI Nexus docs. Renders the nav tree from a
// single source, highlights the active page, and filters by the search box.
const NAV = [
  {
    group: "Start",
    items: [
      { label: "Overview", file: "index.html", tag: "what it is" },
      {
        label: "Getting Started",
        file: "getting-started.html",
        tag: "how to run",
      },
      {
        label: "Architecture",
        file: "architecture.html",
        tag: "how it's made",
      },
      { label: "Examples", file: "examples.html", tag: "recipes" },
    ],
  },
  {
    group: "API Reference",
    items: [
      {
        label: "Core",
        file: "api/core.html",
        pkg: "nexus-core",
        tag: "http server router config",
      },
      {
        label: "Telemetry",
        file: "api/telemetry.html",
        pkg: "nexus-telemetry",
        tag: "logger metrics trace",
      },
      {
        label: "Auth",
        file: "api/auth.html",
        pkg: "nexus-auth",
        tag: "csrf cors jwt oauth session rbac",
      },
      {
        label: "Data (ODM)",
        file: "api/data.html",
        pkg: "nexus-data",
        tag: "odm mongodb schema model query",
      },
      {
        label: "GraphQL",
        file: "api/graphql.html",
        pkg: "nexus-graphql",
        tag: "federation gateway subgraph subscription",
      },
      {
        label: "Realtime",
        file: "api/realtime.html",
        pkg: "nexus-realtime",
        tag: "websocket rooms webrtc mediasoup",
      },
      {
        label: "Payments",
        file: "api/payments.html",
        pkg: "nexus-payments",
        tag: "razorpay paypal payu skrill payoneer",
      },
      {
        label: "Email",
        file: "api/email.html",
        pkg: "nexus-email",
        tag: "smtp nodemailer template queue",
      },
      {
        label: "Crypto",
        file: "api/crypto.html",
        pkg: "nexus-crypto",
        tag: "keypair x509 csr der cert",
      },
      {
        label: "Cache",
        file: "api/cache.html",
        pkg: "nexus-cache",
        tag: "redis rate limiter pubsub",
      },
      {
        label: "Ads",
        file: "api/ads.html",
        pkg: "nexus-ads",
        tag: "google ads gaql campaigns",
      },
      {
        label: "Plugins",
        file: "api/plugins.html",
        pkg: "nexus-plugins",
        tag: "manifest host sandbox worker hooks",
      },
      {
        label: "AI Client",
        file: "api/ai-client.html",
        pkg: "nexus-ai-client",
        tag: "sse streaming openai ollama",
      },
      {
        label: "CLI",
        file: "api/cli.html",
        pkg: "nexus-cli",
        tag: "init dev doctor supervisor",
      },
    ],
  },
  {
    group: "More",
    items: [
      {
        label: "Improvements",
        file: "improvements.html",
        tag: "roadmap suggestions seams",
      },
    ],
  },
];

const SCRIPT_URL =
  document.currentScript?.src || new URL("assets/docs.js", location.href).href;
const DOCS_BASE = new URL("../", SCRIPT_URL);

function routeFromPath(pathname = location.pathname) {
  const route = pathname.startsWith(DOCS_BASE.pathname)
    ? pathname.slice(DOCS_BASE.pathname.length)
    : "index.html";
  return route || "index.html";
}

function currentRoute() {
  return location.hash
    ? decodeURIComponent(location.hash.slice(1)) || "index.html"
    : routeFromPath();
}

const IS_EMBEDDED = new URL(location.href).searchParams.get("embed") === "1";
const IS_SHELL = !IS_EMBEDDED && routeFromPath() === "index.html";
let docFrame;

function routeLabel(route) {
  for (const group of NAV) {
    const item = group.items.find((entry) => entry.file === route);
    if (item) return item.label;
  }
  return "Documentation";
}

function renderSidebar() {
  const sb = document.getElementById("sidebar");
  if (!sb) return;
  const html = [];
  const logoUrl = location.pathname.includes("/api/")
    ? "../assets/bhooai-nexus-logo.svg"
    : "assets/bhooai-nexus-logo.svg";
  html.push(
    `<div class="brand"><img src="${logoUrl}" alt="BhooAI Nexus" /></div>`,
  );
  html.push(
    '<div class="sidebar-meta"><span class="pulse"></span>LOCAL KNOWLEDGE BASE<span class="version">v0.1</span></div>',
  );
  html.push(
    '<input class="search" type="search" placeholder="Filter docs... (press /)" id="nav-search">',
  );
  for (const g of NAV) {
    html.push(`<div class="group-label">${g.group}</div>`);
    for (const it of g.items) {
      const active = it.file === currentRoute() ? " active" : "";
      const pkg = it.pkg ? ` <span class="pkg">@bhooai/${it.pkg}</span>` : "";
      html.push(
        `<a class="nav${active}" href="#${it.file}" data-route="${it.file}" data-tag="${(it.label + " " + (it.tag || "")).toLowerCase()}">${it.label}${pkg}</a>`,
      );
    }
  }
  sb.innerHTML = html.join("");

  const search = document.getElementById("nav-search");
  search.addEventListener("input", () => {
    const q = search.value.toLowerCase().trim();
    sb.querySelectorAll("a.nav").forEach((a) => {
      const match = !q || a.dataset.tag.includes(q);
      a.classList.toggle("hidden", !match);
    });
    sb.querySelectorAll(".group-label").forEach((label) => {
      const anyVisible = label.nextElementSibling;
      let next = label.nextElementSibling;
      let visible = false;
      while (next && !next.classList.contains("group-label")) {
        if (
          next.classList.contains("nav") &&
          !next.classList.contains("hidden")
        )
          visible = true;
        next = next.nextElementSibling;
      }
      label.classList.toggle("hidden", q && !visible);
    });
  });
  search.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const first = sb.querySelector("a.nav:not(.hidden)");
      if (first) location.href = first.getAttribute("href");
    }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "/" && document.activeElement !== search) {
      e.preventDefault();
      search.focus();
    }
    if (e.key === "Escape") search.blur();
  });
}

function updateActiveNav(route) {
  document.querySelectorAll("#sidebar a.nav").forEach((link) => {
    link.classList.toggle("active", link.dataset.route === route);
  });
}

function ensureFrame() {
  if (!IS_SHELL) return;
  const content = document.querySelector("main#content");
  if (!content) return;
  docFrame = document.createElement("iframe");
  docFrame.className = "docs-frame";
  docFrame.title = "BhooAI Nexus documentation content";
  docFrame.loading = "eager";
  content.replaceChildren(docFrame);
}

function frameUrl(route) {
  const url = new URL(route || "index.html", DOCS_BASE);
  url.search = "?embed=1";
  url.hash = "";
  return url.href;
}

async function loadRoute(route, replace = false) {
  const safeRoute = route || "index.html";
  const url = new URL(safeRoute, DOCS_BASE);
  if (IS_SHELL) {
    if (!docFrame) ensureFrame();
    docFrame.src = frameUrl(safeRoute);
    document.title = `BhooAI Nexus Docs - ${routeLabel(safeRoute)}`;
    updateActiveNav(safeRoute);
    if (replace)
      history.replaceState(
        { route: safeRoute },
        "",
        `#${encodeURIComponent(safeRoute)}`,
      );
    window.scrollTo({ top: 0, behavior: "smooth" });
    document.getElementById("sidebar")?.classList.remove("open");
    return;
  }
  try {
    const response = await fetch(url.href);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const html = await response.text();
    const parsed = new DOMParser().parseFromString(html, "text/html");
    const nextContent = parsed.querySelector("main#content");
    const content = document.querySelector("main#content");
    if (!nextContent || !content)
      throw new Error("Documentation page has no #content main");
    content.replaceChildren(
      ...Array.from(nextContent.childNodes).map((node) => node.cloneNode(true)),
    );
    if (parsed.title) document.title = parsed.title;
    updateActiveNav(safeRoute);
    if (replace)
      history.replaceState(
        { route: safeRoute },
        "",
        `#${encodeURIComponent(safeRoute)}`,
      );
    window.scrollTo({ top: 0, behavior: "smooth" });
    document.getElementById("sidebar")?.classList.remove("open");
  } catch (error) {
    // Keep every page directly addressable when opened without a web server.
    console.warn(
      "SPA route loading failed; using the static page instead.",
      error,
    );
    location.href = url.href;
  }
}

function setupSpaRouting() {
  document.addEventListener("click", (event) => {
    const anchor = event.target.closest("a[href]");
    if (!anchor) return;
    const href = anchor.getAttribute("href");
    if (
      !href ||
      href.startsWith("#") ||
      href.startsWith("mailto:") ||
      anchor.target === "_blank"
    )
      return;
    const url = new URL(href, new URL(currentRoute(), DOCS_BASE));
    if (url.origin !== location.origin || !url.pathname.endsWith(".html"))
      return;
    event.preventDefault();
    const route = url.pathname.startsWith(DOCS_BASE.pathname)
      ? url.pathname.slice(DOCS_BASE.pathname.length)
      : "index.html";
    history.pushState({ route }, "", `#${encodeURIComponent(route)}`);
    loadRoute(route);
  });
  window.addEventListener("hashchange", () => loadRoute(currentRoute()));
  window.addEventListener("popstate", () => loadRoute(currentRoute()));
  if (location.hash) loadRoute(currentRoute(), true);
}

function setupEmbeddedRouting() {
  document.body.classList.add("embedded");
  document.addEventListener("click", (event) => {
    const anchor = event.target.closest("a[href]");
    if (!anchor) return;
    const href = anchor.getAttribute("href");
    if (
      !href ||
      href.startsWith("#") ||
      href.startsWith("mailto:") ||
      anchor.target === "_blank"
    )
      return;
    const url = new URL(href, location.href);
    if (url.origin !== location.origin || !url.pathname.endsWith(".html"))
      return;
    event.preventDefault();
    const route = url.pathname.startsWith(DOCS_BASE.pathname)
      ? url.pathname.slice(DOCS_BASE.pathname.length)
      : "index.html";
    window.parent.postMessage({ type: "nexus-docs-route", route }, "*");
  });
}

function setupFrameMessages() {
  if (!IS_SHELL) return;
  window.addEventListener("message", (event) => {
    if (event.source !== docFrame?.contentWindow) return;
    if (event.data?.type !== "nexus-docs-route") return;
    const route = String(event.data.route || "index.html");
    history.pushState({ route }, "", `#${encodeURIComponent(route)}`);
    loadRoute(route);
  });
}

function renderMenuButton() {
  const btn = document.createElement("button");
  btn.className = "menu-btn";
  btn.textContent = "MENU";
  btn.addEventListener("click", () =>
    document.getElementById("sidebar").classList.toggle("open"),
  );
  document.body.appendChild(btn);
}

document.addEventListener("DOMContentLoaded", () => {
  if (IS_EMBEDDED) {
    setupEmbeddedRouting();
    return;
  }
  if (IS_SHELL) document.body.classList.add("shell");
  renderSidebar();
  renderMenuButton();
  if (IS_SHELL) ensureFrame();
  setupSpaRouting();
  setupFrameMessages();
  if (IS_SHELL) loadRoute(currentRoute(), true);
});
